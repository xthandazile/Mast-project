import React , { useState }  from 'react';
import { View,Text,TextInput,Button,StyleSheet,Alert,

} from "react-native";

export default function App() {
  const [name,setName] = useState("");
  const [surname,setSurname] = useState("");
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");

  const handleSubmit = () => {
if (!name|| !surname || !email || !password){
  Alert.alert("Error", "Please complete all fields.");
  return;
}
if(!/^[A-Za-z]+$/ . test(name)){
Alert.alert("Error", "Name must contain letters only.");
}

if(!/^[A-Za-z]+$/.test(surname)) {
  Alert.alert("Error", "Surname must contain letters only.");
return;
}
if(!/^[A-Za-z]+$/.test(email)) {
  Alert.alert("Error", "Email must contain letters and numbers only.");
  return;
}
if(password.length < 8 ) {
  Alert.alert("Error", "Passowrd must be at least  8 characters long.");
  return;
  }
Alert.alert("Success", "login successful!");
};

return(
  <View style={styles.container}>
  <Text style={styles.title}> User  Login Form </Text>

  <TextInput
  style={styles.input}
  placeholder="Enter your name"
  value={name}
  onChangeText ={(text) =>
  setName ( text.replace(/[^A-Za-z]/g,""))
   }
/>

<TextInput
  style={styles.input}
  placeholder="Enter your Surname "
  value={surname}
  onChangeText ={(text) =>
  setSurname ( text.replace(/[^A-Za-z]/g,""))
   }
/>

<TextInput
  style={styles.input}
  placeholder="e.g example@gmail.com"
  value={email}
  onChangeText ={(text) =>
  setEmail ( text.replace(/[^A-Za-z0-9]/g, 
  "")) 
   }
   keyboardType="email-address"
/>

<TextInput
  style={styles.input}
  placeholder="Enter password (8+ characters)"
  value={password}
  onChangeText ={setPassword}/>
  },
  
  secureTextEntry={true}
  
  />
  <Button title="Register"
  onPress={handleSubmit} />
  </View>
);
}

const styles= StyleSheet.create({
  container: {
  flex : 1,
  padding :25,
  justifyContent:"center",
  backgroundColor:"grey",
  },
  title:{
   fontSize:28,
   fontWeight:"bold",
   textAlign:"center",
   marginBottom:30,
  },
  input: {
    height: 50,
    borderWidth:1,
    borderColor:"black",
    borderRadius: 8,
    paddingHorizontal:15,
    marginBottom: 15,
    fontSize :26,
  },
});















