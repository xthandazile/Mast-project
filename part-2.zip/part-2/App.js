import React, { useState } from "react";
import {
   View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Alert,SafeAreaView,
  } from "react-native";
import { Picker } from "@react-native-picker/picker";

export default function App() {
  const [dishName, setDishName] = useState("");
  const [description, setDescription] = useState("");
  const [course, setCourse] = useState("");
  const [price, setPrice] = useState("");

  const [menuItems, setMenuItems] = useState([]);

  const addMenuItem = () => {

 if (!dishName.trim()) {
 Alert.alert("Required", "Please enter the dish name.");
 return;
 }

if (!description.trim()) {
    Alert.alert("Required", "Please enter a description.");
    return;
  }

    if (!course) {
      Alert.alert("Required", "Please select a course.");
      return;
    }

    if (!price.trim()) {
      Alert.alert("Required", "Please enter the price.");
      return;
    }

  
    const newItem = {
      id: Date.now().toString(),
      dishName: dishName,
      description: description,
      course: course,
      price: parseFloat(price).toFixed(2),
    };

  
    setMenuItems([...menuItems, newItem]);

  
    setDishName("");
    setDescription("");
    setCourse("");
    setPrice("");

    Alert.alert("Success", "Menu item added successfully!");
  };

  const renderMenuItem = ({ item }) => (
    <View style={styles.menuCard}>
      <Text style={styles.dishName}>{item.dishName}</Text>

      <Text style={styles.course}>
        {item.course}
      </Text>

      <Text style={styles.description}>
        {item.description}
      </Text>

      <Text style={styles.price}>
        R{item.price}
      </Text>
    </View>
  );

  return (
 <SafeAreaView style={styles.container}>
 <FlatList
 data={menuItems}
keyExtractor={(item) => item.id}
renderItem={renderMenuItem}
ListHeaderComponent={
<>
<Text style={styles.title}>Chef Menu </Text>

<Text style={styles.total}>
Total Menu Items: {menuItems.length}
</Text>

<View style={styles.form}>
<Text style={styles.label}>Dish Name</Text>

<TextInput
style={styles.input}
placeholder="Enter dish name"
value={dishName}
onChangeText={setDishName}
/>

<Text style={styles.label}>Description</Text>

<TextInput
style={[styles.input, styles.textArea]}
placeholder="Enter dish description"
value={description}
onChangeText={setDescription}
multiline
 />

<Text style={styles.label}>Select Course</Text>

<View style={styles.pickerContainer}>
<Picker
selectedValue={course}
onValueChange={(itemValue) => setCourse(itemValue)}
>
<Picker.Item
label="Select a course"
value=""
/>
<Picker.Item
label="Starter"
value="Starter"
/>
<Picker.Item
label="Main Course"
value="Main Course"
/>
<Picker.Item
label="Dessert"
value="Dessert"
/>

</Picker>
</View>

<Text style={styles.label}>Price</Text>
<TextInput
style={styles.input}
placeholder="Enter price e.g. 120.00"
value={price}
onChangeText={setPrice}
 keyboardType="decimal-pad"
/>

<TouchableOpacity
style={styles.button}
onPress={addMenuItem}
>
<Text style={styles.buttonText}>
+ Add Menu Item
</Text>
</TouchableOpacity>
<Text style={styles.menuTitle}>
Prepared Menu
</Text>

{menuItems.length === 3 && (
<Text style={styles.emptyMessage}>
No menu items have been added yet.
</Text>
 )}
</View>
</>
}
contentContainerStyle={styles.list}
/>
</SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "light grey",
  },

  list: {
    padding: 20,
    paddingBottom: 40,
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 10,
  },

  total: {
    textAlign: "center",
    fontSize: 17,
    marginBottom: 20,
    color: "dark grey",
  },

  form: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
  },

  label: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 7,
    marginTop: 10,
  },

  input: {
    borderWidth: 1,
    borderColor: "light gray",
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: "white",
  },

  textArea: {
    height: 90,
    textAlignVertical: "top",
  },

  pickerContainer: {
    borderWidth: 1,
    borderColor: "light gray",
    borderRadius: 8,
    overflow: "hidden",
    backgroundColor: "white",
  },

  button: {
    backgroundColor: "grey",
    padding: 15,
    borderRadius: 8,
    marginTop: 20,
    alignItems: "center",
  },

  buttonText: {
    color: "white",
    fontSize: 17,
    fontWeight: "bold",
  },

  menuTitle: {
    fontSize: 22,
    fontWeight: "bold",
    marginTop: 30,
    marginBottom: 10,
  },

  emptyMessage: {
    textAlign: "center",
    color: "grey",
    padding: 20,
  },

  menuCard: {
    backgroundColor: "white",
    padding: 18,
    borderRadius: 12,
    marginBottom: 15,
    elevation: 3,
  },

  dishName: {
    fontSize: 21,
    fontWeight: "bold",
  },

  course: {
    fontSize: 14,
    color: "green",
    fontWeight: "bold",
    marginTop: 5,
  },

  description: {
    fontSize: 15,
    color: "dark grey",
    marginTop: 8,
  },

  price: {
    fontSize: 18,
    fontWeight: "bold",
    marginTop: 10,
  },
});